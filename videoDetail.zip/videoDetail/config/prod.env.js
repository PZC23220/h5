module.exports = {
  NODE_ENV: '"prod"'
}
