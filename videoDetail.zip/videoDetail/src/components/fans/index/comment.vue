<template>
	<div class="main_page">
		<div class="publish">留言</div>
		<ul class="comment_list dynamic">
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
				<div class="comment_desc">
					<span><img src="" alt="">274,223</span>
					<span><img src="" alt="">3434</span>
					<span><img src="" alt=""><img src="" alt=""></span>
				</div>
			</li>
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
			</li>
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
			</li>
		</ul>
	</div>
</template>

<style rel="stylesheet/scss" lang="scss" scoped>
	.publish {
		color: #fff;
		background: #ACACAC;
		border-radius: 3px;
		width: 276px;
		height: 38px;
		line-height: 38px;
		margin: 10.5px auto;
		text-align: center;
		font-size: 18px;
	}
 .comment_list {
 	padding: 0;
 	li {
 		padding: 11px 12px;
 		border-bottom: 4px solid #F2F2F2;
 	}
 }
</style>