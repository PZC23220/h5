<template>
    <div class="main">
        <div class="content">
           <div class="desc">
               <h5>{{medal_text.title}}</h5>
               <ul>
                   <li><img src="../../images/icon_medal_1.png" alt=""><span>{{medal_text.medal1}}</span><i v-if="medal_text.value=='Like数'">ブロンズキュウシュゴ</i><div><span>{{medal_text.value}}</span><i>2000</i></div><p>{{medal_text.desc}}</p></li>
                   <li><img src="../../images/icon_medal_2.png" alt=""><span>{{medal_text.medal2}}</span><i v-if="medal_text.value=='Like数'">シルバーキュウシュゴ</i><div><span>{{medal_text.value}}</span><i>5000</i></div><p>{{medal_text.desc}}</p></li>
                   <li><img src="../../images/icon_medal_3.png" alt=""><span>{{medal_text.medal3}}</span><i v-if="medal_text.value=='Like数'">ゴールドキュウシュゴ</i><div><span>{{medal_text.value}}</span><i>15000</i></div><p>{{medal_text.desc}}</p></li>
                   <li><img src="../../images/icon_medal_4.png" alt=""><span>{{medal_text.medal4}}</span><i v-if="medal_text.value=='Like数'">ダイヤモンドキュウシュゴ</i><div><span>{{medal_text.value}}</span><i>30000</i></div><p>{{medal_text.desc}}</p></li>
                   <li><img src="../../images/icon_medal_5.png" alt=""><span>{{medal_text.medal5}}</span><i v-if="medal_text.value=='Like数'">キングキュウシュゴ</i><div><span>{{medal_text.value}}</span><i>50000</i></div><p>{{medal_text.desc}}</p></li>
               </ul>
           </div>
        </div>
    </div>
</template>

<script>
   export default {
        data() {
            return {
                medal_text: {
                    title: 'ファンがGroupyでの総合応援アクションを表現したものです。アイドルを応援すればするほど、レベルアップを達成できます。',
                    medal1: '青銅級守護',
                    medal2: '白銀級守護',
                    medal3: '黄金級守護',
                    medal4: '金剛級守護',
                    medal5: '王者級守護',
                    value: 'Like数',
                    desc: 'アイドルかユニットごとにLikeと同等価値の応援'
                }
            }
        },
        methods: {
            close() {
                window.setupWebViewJavascriptBridge(function(bridge) {
                    bridge.callHandler('close');
                });
            }
        },
        created() {
            var self = this;
            let _lan = (navigator.browserLanguage || navigator.language).toLowerCase();
            if(_lan === 'zh-cn') {
                 self.medal_text= {
                    title: 'level是根据粉丝在Groupy平台所送的人气划分的。送出人气和礼物越多，代表该粉丝是越资深的用户，level也会越高',
                    medal1: '青铜守护',
                    medal2: '白金守护',
                    medal3: '黄金守护',
                    medal4: '钻石守护',
                    medal5: '王者守护',
                    value: '价值满',
                    desc: '为单个爱豆或组合送出'

                }
            } else {
                self.medal_text= {
                    title: 'ファンがGroupyでの総合応援アクションを表現したものです。アイドルを応援すればするほど、レベルアップを達成できます。',
                    medal1: '青銅級守護',
                    medal2: '白銀級守護',
                    medal3: '黄金級守護',
                    medal4: '金剛級守護',
                    medal5: '王者級守護',
                    value: 'Like数',
                    desc: 'アイドルかユニットごとにLikeと同等価値の応援'
                }
            }
        }
    } 
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .content {
        top: 0;
        color: #666;
        height: 100vh;
        font-weight: 200;
        background: #eee;
        .desc {
            padding: 8px 12px;
            h5 {
                color: #999;
            }
            ul {
                overflow: hidden;
                padding-top: 8.5px;
                li {
                    float: left;
                    box-sizing: border-box;
                    width: calc(50% - 6px);
                    background: #FCFCFC;
                    box-shadow: 0 1px 2px 0 rgba(0,0,0,0.20);
                    border-radius: 4px;
                    margin-bottom: 12px;
                    &:nth-child(2n) {
                        margin-left: 12px;
                    }
                    text-align: center;
                    padding-top: 19.5px;
                    padding-bottom: 5px;
                    >img {
                        width: 105px;
                        display: block;
                        margin: 0 auto 15px;
                    }
                    >span {
                        font-size: 14px;
                    }
                    >i {
                        display: block;
                        color: #999;
                        font-size: 10px;
                        -webkit-transform: scale(0.8);
                    }
                    >div {
                        padding-top: 5px;
                        span {
                            display: inline-block;
                            width: 58px;
                            height: 16px;
                            line-height: 16px;
                            background: url(../../images/bg_medal.png) no-repeat;
                            background-size: 100% 100%;
                            color: #fff;
                            font-size: 9px;
                            -webkit-transform: scale(0.75);
                        }
                        i {
                            font-family: 'Helvetica Condensed Bold Italic';
                            font-size: 18px;
                            color: #333;
                        }
                    }
                    >p {
                        color: #999;
                        font-size: 10px;
                        -webkit-transform: scale(0.8);
                    }
                    &:last-child {
                        width: 100%;
                    }
                }
            }
        }
    }
    @font-face {
      font-family: 'Helvetica Condensed Bold Italic';
      src: url('../../font/Helvetica Condensed Bold Italic.eot');
      src: url('../../font/Helvetica Condensed Bold Italic.woff2') format('woff2'),
           url('../../font/Helvetica Condensed Bold Italic.eot?#iefix') format('embedded-opentype');
    }
</style>
