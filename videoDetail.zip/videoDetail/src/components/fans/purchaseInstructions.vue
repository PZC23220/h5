<template>
    <div class="main">
        <div class="content" style=" top: 0;height: 100vh;">
            <h3 class="rule_tile">1.使用可能範囲</h3>
            <p class="rule_content">・Groupyコインは、「Groupy」という名称のウェブサイト・アプリケーション内でのデジタルコンテンツ・会員登録の購入の代金決済にご利用いただけます。デジタルコンテンツ・会員登録等の表示価格は、消費税込みのものとなっております。</p>
            <p class="rule_content">・iOS端末で購入したコインをiOS以外の端末で利用することはできません。</p>
            <h3 class="rule_tile">2.有効期間・期限</h3>
            <p class="rule_content">    iOS 端末で購入したコインは有効期限の設定なしとなっております。なお、お客様がGroupyの利用資格を喪失した場合は、未使用分のコインも消滅するものとします。</p>
            <h3 class="rule_tile">3.免責事項</h3>
            <p class="rule_content"> ・コインの購入手続完了から反映まで、時間がかかる場合がございます。Groupyでは、コインコインの払戻しは行っておりません。またお客様ご自身の操作でお客様に生じた損害について、Groupyは一切責任を負いません。</p>
            <p class="rule_content"> ・アカウントの他者への貸与が行われたと疑われる場合、不正ルートまたは悪質なハッキングでコインを増やした場合その他不正利用の疑いがある場合には、調査のためご利用を制限させていただくことがあります。管理人によってアカウントが凍結される可能性もございます。また法律に基づき当社からお客様への損害請求が発生する場合がございますのでご了承ください。</p>
            <p class="rule_content">・法規定に従い、Groupyはコイン制度に関して変更、調整、中止及び停止を自由に行うっ権利を有するものとします。</p>
            <h3 class="rule_tile">4.お問い合わせ</h3>
            <p class="rule_content"> お支払いは終了しているのに購入が完了しないの場合等は以下のお問い合わせ先までお願いいたします。<br>&nbsp;&nbsp;&nbsp;&nbsp;ニュースジェット株式会社<br>&nbsp;&nbsp;&nbsp;&nbsp;〒130-0026　東京都墨田区両国2丁目2-10  702室<br>&nbsp;&nbsp;&nbsp;&nbsp;メール：<i>fans@groupy.vip</i></p>
        </div>
    </div>
</template>