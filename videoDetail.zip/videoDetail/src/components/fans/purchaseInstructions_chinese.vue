<template>
    <div class="main">
        <div class="content" style=" top: 0;height: 100vh;">
            <h3 class="rule_tile">1.使用范围说明</h3>
            <p class="rule_content">・“G币”是Groupy团队向用户提供的用于在Groupy App上进行购买虚拟礼物、加入会员等相关消费的虚拟货币。在Groupy上显示的虚拟礼物、加入会员等价格，均为税后价格。</p>
            <p class="rule_content">・在iOS端购买的G币不支持在iOS端以外的平台进行使用。</p>
            <h3 class="rule_tile">2.G币使用期限</h3>
            <p class="rule_content">    在iOS端充值的G币没有设置使用有效期限。但是，如果用户失去了Groupy的使用资格，剩余的G币将不可用于购买平台上的虚拟产品或服务，同时Groupy有权不予返还用户购买G币时的现金价值。</p>
            <h3 class="rule_tile">3.免责声明</h3>
            <p class="rule_content">・G币从购买支付结束到成功到账需要一定的时间。充值成功后，Groupy不会提供任何退还或逆向兑换服务。同时，若因为您操作不当等因素造成充值错误等情形损害自身利益的，Groupy将不会作出任何补偿或赔偿。</p>
            <p class="rule_content"> ・如果用户违规将Groupy账号出借给第三方、通过其他非Groupy认可的渠道充值G币、非法使用G币等，则Groupy有权冻结该账户进行调查，严重者可以进行封号处理。同时，Groupy有权依法向用户索取相应赔偿。</p>
            <p class="rule_content">・Groupy保留不在事先通知用户的情况下，随时依法更改、中断、或终止部分或全部网络充值服务的权利。</p>
            <h3 class="rule_tile">4.帮助与反馈</h3>
            <p class="rule_content"> 如果由于Groupy系统故障等原因导致您支付后G币却没到账等困扰，请通过以下方式及时与Groupy取得联系。<br>&nbsp;&nbsp;&nbsp;&nbsp;NewsJet科技有限公司<br>&nbsp;&nbsp;&nbsp;&nbsp;〒130-0026　東京都墨田区两国2丁目2-10  702室<br>&nbsp;&nbsp;&nbsp;&nbsp;邮箱：<i>fans@groupy.vip</i></p>
        </div>
    </div>
</template>