<template>
	<div class="main_page">
		<ul class="comment_list">
			<li>
				<div class="comment_info">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>05.12&nbsp;&nbsp;12:00</i>
				</div>
				<div class="comment_content">ありがとうございます！超嬉しかった！きっといい点数取れまーす(≧∇≦)/</div>
			</li>
			<li>
				<div class="comment_info">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>05.12&nbsp;&nbsp;12:00</i>
				</div>
				<div class="comment_content">ありがとうございます！超嬉しかった！きっといい点数取れまーす(≧∇≦)/</div>
			</li>
			<li>
				<div class="comment_info">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>05.12&nbsp;&nbsp;12:00</i>
				</div>
				<div class="comment_content">ありがとうございます！超嬉しかった！きっといい点数取れまーす(≧∇≦)/</div>
			</li>
		</ul>
	</div>
</template>