<template>
	<div class="main_page">
		<ul class="comment_list">
			<li>
				<img src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
			<li>
				<img src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
			<li>
				<img src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
			<li>
				<img src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
		</ul>
	</div>
</template>