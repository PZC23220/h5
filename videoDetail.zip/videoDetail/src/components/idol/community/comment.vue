<template>
	<div class="main_page">
		<ul class="comment_list dynamic">
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
			</li>
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
			</li>
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
			</li>
		</ul>
	</div>
</template>