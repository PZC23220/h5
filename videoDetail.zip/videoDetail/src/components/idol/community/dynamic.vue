<template>
	<div class="main_page">
		<div class="publish">
			<span>发布总数 <i>13</i></span>
			<span class="right">＋&nbsp;发布状态</span>
		</div>
		<ul class="comment_list dynamic">
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
				<div class="comment_desc">
					<span><img src="" alt="">274,223</span>
					<span><img src="" alt="">3434</span>
					<span><img src="" alt=""><img src="" alt=""></span>
				</div>
			</li>
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
			</li>
			<li>
				<div class="userinfo">
					<img src="" alt="">
					<span>結月 みおな</span>
					<i>18:10&nbsp;&nbsp;05.12</i>				
				</div>
				<div class="comment_content">
					<p>#オフショットや日常写真# No.127</p>
					<img src="" alt="">
				</div>
			</li>
		</ul>
	</div>
</template>

<style rel="stylesheet/scss" lang="scss" scoped>
 .comment_list {
 	padding: 0;
 	li {
 		padding: 11px 12px;
 		border-bottom: 4px solid #F2F2F2;
 	}
 }
</style>