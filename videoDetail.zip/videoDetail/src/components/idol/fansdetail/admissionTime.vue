<template>
	<div class="main_page">
		<ul class="comment_list">
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i>2017.5.5</i>
			</li>
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i>2017.5.5</i>
			</li>
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i>2017.5.5</i>
			</li>
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i>2017.5.5</i>
			</li>
		</ul>
	</div>
</template>