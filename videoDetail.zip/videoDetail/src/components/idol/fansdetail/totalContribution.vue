<template>
	<div class="main_page">
		<ul class="comment_list">
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i><img src="" alt="" class="icon">1,689</i>
			</li>
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i><img src="" alt="" class="icon">1,689</i>
			</li>
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i><img src="" alt="" class="icon">1,689</i>
			</li>
			<li>
				<img class="user_img" src="" alt="">
				<span>結月 みおな</span>
				<i><img src="" alt="" class="icon">1,689</i>
			</li>
		</ul>
	</div>
</template>