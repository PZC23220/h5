<template>
	<div class="main_page">
		<div class="income">
			<span class="detail_title">总收入</span>
			<span><img src="" alt="" class="icon"><i class="video_money">31,256</i></span>
		</div>
		<div class="income_details">
			<p class="detail_title">收入详情</p>
			<ul class="income_img">
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;20</span></p>
				</li>
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;30</span></p>
				</li>
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;50</span></p>
				</li>
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;50</span></p>
				</li>
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;50</span></p>
				</li>
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;50</span></p>
				</li>
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;50</span></p>
				</li>
				<li>
					<img class="gift" src="" alt="">
					<p><span class="left">&times;50</span></p>
				</li>
			</ul>
		</div>
		<div class="fans_detail">
			<p class="detail_title">粉丝详情</p>
			<ul class="comment_list">
			<li>
				<span>1</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<img src="" class="level" alt="">
				<!-- <embed src="./icon_level.svg" class="level" type="image/svg+xml"pluginspage="http://www.adobe.com/svg/viewer/install/" /> -->
				<i>
					<img src="" class="likes" alt="">
					&nbsp;&nbsp;1,689
				</i>
			</li>
			<li>
				<span>2</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
			<li>
				<span>3</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
			<li>
				<span>4</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
		</ul>
		</div>
	</div>
</template>

<style lang="scss" scoped>
	.comment_list {
		padding: 0;
	}
</style>