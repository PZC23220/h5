<template>
	<div class="main_page">
		<ul class="comment_list">
			<li>
				<span>1</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<img src="" class="level" alt="">
				<!-- <embed src="./icon_level.svg" class="level" type="image/svg+xml"pluginspage="http://www.adobe.com/svg/viewer/install/" /> -->
				<i>
					<img src="" class="likes" alt="">
					&nbsp;&nbsp;1,689
				</i>
			</li>
			<li>
				<span>2</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
			<li>
				<span>3</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
			<li>
				<span>4</span>
				<img class="avatar" src="" alt="">
				<span>結月 みおな</span>
				<i>like 数&nbsp;&nbsp;1,689</i>
			</li>
		</ul>
	</div>
</template>